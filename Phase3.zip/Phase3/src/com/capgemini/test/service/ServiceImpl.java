package com.capgemini.test.service;

import com.capgemini.test.dao.DaoImpl;
import com.capgemini.test.dao.DaoInterface;
import com.capgemini.test.entity.Account;

public class ServiceImpl implements Service {

	DaoInterface data = new DaoImpl();
	
	@Override
	public boolean validateUserName(String userName) {
		if (userName.matches(USER_NAME_PATTERN))
			return true;
		else
			return false;
	}

	@Override
	public boolean validateMobile(String mobile) {
		if (mobile.matches(MOBILE_PATTERN))
			return true;
		else
			return false;
	}

	@Override
	public boolean validateEmail(String email) {
		if (email.matches(EMAIL_PATTERN))
			return true;
		else
			return false;
	}


	@Override
	public void fetchAccount(int id) {
		data.beginTransaction();
		data.fetchAccount(id);
		data.commitTransaction();
		
	}

	@Override
	public void openAccount(Account acc) {
		data.beginTransaction();
		data.openAccount(acc);
		data.commitTransaction();
		
	}

	@Override
	public void deposit(int accId, double amount) {
		data.beginTransaction();
		data.deposit(accId, amount);
		data.commitTransaction();
		
	}

	@Override
	public boolean validateEntry(String ch) {
		if (ch.matches(ENTRY))
			return true;
		else
			return false;
	}

	@Override
	public boolean validateAccId(String userAccId) {
		if (userAccId.matches(ACC_NO))
			return true;
		else
			return false;
	}

	@Override
	public boolean validateAddress(String holderAddress) {
		if(holderAddress.matches(ADDRESS_PATTERN))
			return true;
		else
			return false;
	}

	@Override
	public boolean validateAmount(String amount) {
		if(amount.matches(AMOUNT))
			return true;
		else
			return false;
	}

}
