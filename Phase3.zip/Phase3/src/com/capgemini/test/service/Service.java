package com.capgemini.test.service;

import com.capgemini.test.entity.Account;

public interface Service {
	
	String ENTRY = "[1-7]{1}";
	String FIRST_CHOICE="[1-2]{1}";
	String ACC_NO = "[0-9]{7}";
	
	String AMOUNT = "[0-9]{1,10}";
	String USER_NAME_PATTERN = "[a-zA-Z]{1,10}";
	String ADDRESS_PATTERN = "[A-Za-z]{1,25}";
	String MOBILE_PATTERN = "[0-9]{10}";
	String EMAIL_PATTERN = "^[\\w-\\+]+(\\.[\\w]+)*@[\\w-]+(\\.[\\w]+)*(\\.[a-z]{2,})$";
	
	boolean validateMobile(String mobile);

	boolean validateEmail(String email);
	boolean validateAmount(String amount);
	boolean validateEntry(String ch);

	boolean validateAccId(String userAccId);
	
	void fetchAccount(int id);
	void openAccount(Account acc);
	void deposit(int accId, double amount);

	boolean validateUserName(String userName);

	boolean validateAddress(String holderAddress);

}
