package com.capgemini.test.dao;

import javax.persistence.EntityManager;

import oracle.net.ns.NetInputStream;

import com.capgemini.test.entity.Account;

public class DaoImpl implements DaoInterface {

	double bal;
	private EntityManager entityManager;

	public DaoImpl() {
		entityManager = JPAUtil.getEntityManager();
	}

	@Override
	public void openAccount(Account acc) {
		acc.setBalance(1000);

		entityManager.persist(acc);

	}

	@Override
	public void deposit(int accID, double amount) {
		Account accnt = entityManager.find(Account.class, accID);
		
		if(accnt!=null){
			bal = accnt.getBalance();
			accnt.setBalance(bal + amount);
		}
		System.out.println("Updated balance is : " + accnt.getBalance());
	}

	@Override
	public void fetchAccount(int id) {
		Account accnt = entityManager.find(Account.class, id);

		System.out.println(accnt);
	}

	@Override
	public void commitTransaction() {
		entityManager.getTransaction().commit();
	}

	@Override
	public void beginTransaction() {
		entityManager.getTransaction().begin();
	}

}
