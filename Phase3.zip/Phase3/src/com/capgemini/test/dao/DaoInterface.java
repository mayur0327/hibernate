package com.capgemini.test.dao;

import com.capgemini.test.entity.Account;

public interface DaoInterface {
	int MIN_BALANCE = 0;

	void openAccount(Account acc);

	void deposit(int accID, double amount);

	void fetchAccount(int id);

	public abstract void commitTransaction();

	public abstract void beginTransaction();
}
