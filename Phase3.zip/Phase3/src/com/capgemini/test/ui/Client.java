package com.capgemini.test.ui;

import java.util.Scanner;

import com.capgemini.test.entity.Account;
import com.capgemini.test.service.Service;
import com.capgemini.test.service.ServiceImpl;

public class Client {
	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		String holderName;
		String holderEmail;
		String holderNumber;
		String holderAddress;
		String ch;
		int accNo;
		String depositAmount;
		Service sobj = new ServiceImpl();
		boolean isValid;

		

		while (true) {
			while (true) {
				System.out.println("***Menu***");
				System.out
						.println("1. Create Account \n2. Fetch Details \n3. Deposit \n4. Exit");
				ch = scan.next();
				isValid = sobj.validateEntry(ch);
				if (isValid)
					break;
				else
					System.out.println("Please enter Valid Choice 1 or 6");
			}
			switch (ch) {
			case "1":
				System.out.println("Welcome");
				while (true) {

					System.out.println("Enter name");
					holderName = scan.next();

					isValid = sobj.validateUserName(holderName);
					if (isValid)
						break;
					else
						System.out
								.println("Please enter Valid Name.\nName should have minimum 1 or max 10 character \nFirst letter must be capital");
				}
				while (true) {

					System.out.println("Enter Email");
					holderEmail = scan.next();

					isValid = sobj.validateEmail(holderEmail);
					if (isValid)
						break;
					else
						System.out
								.println("Please enter Valid Email(eg abc@gmail.com)");
				}
				while (true) {

					System.out.println("Enter mobile");
					holderNumber = scan.next();

					isValid = sobj.validateMobile(holderNumber);
					if (isValid)
						break;
					else
						System.out
								.println("Please enter Valid Mobile without +91 (eg. 9167968584)");
				}
				while (true) {

					System.out.println("Enter Address");
					holderAddress = scan.next();

					isValid = sobj.validateAddress(holderAddress);
					if (isValid)
						break;
					else
						System.out
								.println("Please enter Valid Mobile without +91 (eg. 9167968584)");
				}
				Account aobj = new Account();
				aobj.setName(holderName);
				aobj.setMobile(holderNumber);
				aobj.setEmail(holderEmail);
				aobj.setAddress(holderAddress);
				System.out.println("Inserting into Database");
				sobj.openAccount(aobj);
				break;

			case "2":

				System.out.println("Enter Account Number");
				accNo = scan.nextInt();
				sobj.fetchAccount(accNo);

				break;

				
			case "3":
				while(true){
				System.out.println("Enter Account Number");
				accNo = scan.nextInt();
				
				System.out.println("Enter amount to deposit");
				depositAmount = scan.next();
				
				isValid = sobj.validateAmount(depositAmount);
				if(isValid)
					break;
				else
					System.out.println("Enter Amount again");
				}
				sobj.deposit(accNo, Integer.parseInt(depositAmount));
				break;
			case "4":
				System.out.println("Exiting..");
				System.exit(0);
				scan.close();

			}
		}

	}
}